# WitchHunt
Game with Scripts
Modelos 2 Integrantes: 
<ol>
<li>Sebastian Camilo Vanegas Ayala - 20151020016</li> 
<li>Jonathan Steven Capera Quintana - 20151020001</li> 
<li>Daniel David Leal Lara - 20151020057</li>
</ol>
